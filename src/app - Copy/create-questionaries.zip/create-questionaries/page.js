'use client';
import { useState } from "react";
import { DragDropContext, Droppable, Draggable } from "react-beautiful-dnd";

const QuestionnaireForm = () => {
  const [title, setTitle] = useState("");
  const [description, setDescription] = useState("");
  const [questions, setQuestions] = useState([
    {
      question: "",
      description: "",
      type: "multipleChoice",
      options: [""],
    },
  ]);

  const handleTitleChange = (e) => setTitle(e.target.value);

  const handleDescriptionChange = (e) => setDescription(e.target.value);

  const handleQuestionChange = (index, field, value) => {
    const updatedQuestions = [...questions];
    updatedQuestions[index][field] = value;
    setQuestions(updatedQuestions);
  };

  const handleOptionChange = (index, optionIndex, value) => {
    const updatedQuestions = [...questions];
    updatedQuestions[index].options[optionIndex] = value;
    setQuestions(updatedQuestions);
  };

  const addQuestion = () => {
    setQuestions([
      ...questions,
      {
        question: "",
        description: "",
        type: "multipleChoice",
        options: [""],
      },
    ]);
  };

  const addOption = (index) => {
    const updatedQuestions = [...questions];
    updatedQuestions[index].options.push("");
    setQuestions(updatedQuestions);
  };

  const handleDragEnd = (result) => {
    const { source, destination } = result;
    if (!destination) return;

    const reorderedQuestions = [...questions];
    const [movedQuestion] = reorderedQuestions.splice(source.index, 1);
    reorderedQuestions.splice(destination.index, 0, movedQuestion);
    setQuestions(reorderedQuestions);
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    const questionnaireData = { title, description, questions };
    console.log("Form Submitted: ", questionnaireData);
  };

  return (
    <div className="container mx-auto p-4">
      <h1 className="text-xl font-bold mb-4">Create Questionnaire</h1>
      <form onSubmit={handleSubmit}>
        {/* Title and Description */}
        <div className="mb-2">
          <label className="block text-sm font-medium">Title</label>
          <input
            type="text"
            value={title}
            onChange={handleTitleChange}
            className="w-full p-2 border border-gray-300 rounded text-sm"
            required
          />
        </div>
        <div className="mb-2">
          <label className="block text-sm font-medium">Description</label>
          <textarea
            value={description}
            onChange={handleDescriptionChange}
            className="w-full p-2 border border-gray-300 rounded text-sm"
            rows="2"
            required
          />
        </div>

        {/* Questions */}
        <DragDropContext onDragEnd={handleDragEnd}>
          <Droppable droppableId="questions" type="list">
            {(provided) => (
              <div
                className="mb-4"
                ref={provided.innerRef}
                {...provided.droppableProps}
              >
                {questions.map((question, index) => (
                  <Draggable key={index} draggableId={String(index)} index={index}>
                    {(provided) => (
                      <div
                        className="mb-3 p-2 border border-gray-300 rounded bg-gray-50 text-sm flex items-start"
                        ref={provided.innerRef}
                        {...provided.draggableProps}
                      >
                        {/* Drag Handle */}
                        <div
                          className="p-2 cursor-grab text-gray-500"
                          {...provided.dragHandleProps}
                        >
                          &#x2630;
                        </div>

                        {/* Question Content */}
                        <div className="flex-grow">
                          <div className="mb-2">
                            <label className="block font-medium">Question {index + 1}</label>
                            <input
                              type="text"
                              value={question.question}
                              onChange={(e) =>
                                handleQuestionChange(index, "question", e.target.value)
                              }
                              className="w-full p-1 border border-gray-300 rounded"
                              required
                            />
                          </div>

                          <div className="mb-2">
                            <label className="block font-medium">Description</label>
                            <textarea
                              value={question.description}
                              onChange={(e) =>
                                handleQuestionChange(index, "description", e.target.value)
                              }
                              className="w-full p-1 border border-gray-300 rounded"
                              rows="1"
                            />
                          </div>

                          <div className="mb-2">
                            <label className="block font-medium">Type</label>
                            <select
                              value={question.type}
                              onChange={(e) =>
                                handleQuestionChange(index, "type", e.target.value)
                              }
                              className="w-full p-1 border border-gray-300 rounded"
                            >
                              <option value="multipleChoice">Multiple Choice</option>
                              <option value="paragraph">Paragraph</option>
                              <option value="shortAnswer">Short Answer</option>
                              <option value="trueFalse">True/False</option>
                              <option value="yesNo">Yes/No</option>
                            </select>
                          </div>

                          {question.type === "multipleChoice" && (
                            <div>
                              <label className="block font-medium">Options</label>
                              {question.options.map((option, optionIndex) => (
                                <div key={optionIndex} className="flex items-center mb-1">
                                  <input
                                    type="text"
                                    value={option}
                                    onChange={(e) =>
                                      handleOptionChange(index, optionIndex, e.target.value)
                                    }
                                    className="w-full p-1 border border-gray-300 rounded text-sm"
                                    placeholder={`Option ${optionIndex + 1}`}
                                  />
                                </div>
                              ))}
                              <button
                                type="button"
                                onClick={() => addOption(index)}
                                className="text-blue-500 text-xs"
                              >
                                Add Option
                              </button>
                            </div>
                          )}
                        </div>
                      </div>
                    )}
                  </Draggable>
                ))}
                {provided.placeholder}
              </div>
            )}
          </Droppable>
        </DragDropContext>

        <button
          type="button"
          onClick={addQuestion}
          className="text-blue-500 text-sm mb-2"
        >
          Add Question
        </button>

        {/* Submit */}
        <div>
          <button
            type="submit"
            className="px-3 py-1 bg-blue-500 text-white text-sm rounded"
          >
            Submit Questionnaire
          </button>
        </div>
      </form>
    </div>
  );
};

export default QuestionnaireForm;
