import SignIn from "./signin/page";

export default function Home() {
  return <SignIn />
}
