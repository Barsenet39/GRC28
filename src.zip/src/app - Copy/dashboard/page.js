export default function Dashboard() {
    return (
      <div className="p-8">
        <h1 className="text-3xl font-bold">Dashboard</h1>
        <p className="mt-4">Welcome to the Dashboard. You can promote something here.</p>
        {/* You can add other content here */}
      </div>
    );
  }
  