"use client";

import React, { useState } from 'react';
import { useRouter } from 'next/navigation';
import { FaDownload, FaEye } from "react-icons/fa";
import { FaFileAlt } from 'react-icons/fa'; // Import the document icon
import { FaBuilding, FaMapMarkerAlt, FaPhone, FaEnvelope, FaIdCard, FaCalendarAlt, FaProjectDiagram } from "react-icons/fa"; // More Icons

const RequestOverview = () => {
  const router = useRouter();
  const [activeComment, setActiveComment] = useState(null);
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [file, setFile] = useState(null);
  const [showApprovalComment, setShowApprovalComment] = useState(false);
  const [decision, setDecision] = useState(null);
  const [priority, setPriority] = useState(null);
  const [commentsText, setCommentsText] = useState('');
  const [showSentPopup, setShowSentPopup] = useState(false);
  const [selectedApprovalRole, setSelectedApprovalRole] = useState(null);
  const [uploadError, setUploadError] = useState(null);
  const [showUploadedPopup, setShowUploadedPopup] = useState(false);


  // Single approvalStatus declaration
  const approvalStatus = [
    { role: 'Directorate Director Approval', status: 'pending', comment: 'Pending review of security assessment details' },
    { role: 'Division Head Approval', status: 'pending', comment: 'Pending review of security assessment details' }
  ];

  const handleView = (role) => {
    setSelectedApprovalRole(role);
    setShowApprovalComment(true);
    console.log(`Viewing details for: ${role}`);
  };

  const comments = {
    DivisionHead: (
      <>
        <div className="text-center">Request accepted</div>
        <div className="text-center">Date: 18 Jan, 2021</div>
        <div className="text-center">By: Division Head</div>
      </>
    ),
  };

  const toggleComments = (role) => setActiveComment(role);
  const closeModal = () => setActiveComment(null);
  const handleNavigate = () => router.push('/template');
  const handleUploadClick = () => setIsModalOpen(true);

  const handleDrop = (event) => {
    event.preventDefault();
    const droppedFile = event.dataTransfer.files[0];
    handleFileValidation(droppedFile);
  };

  const handleFileChange = (event) => {
    const selectedFile = event.target.files[0];
    handleFileValidation(selectedFile);
  };

  const handleFileValidation = (selectedFile) => {
    setUploadError(null); // Reset error

    if (!selectedFile) return;

    if (selectedFile.type !== 'application/pdf') {
      setUploadError('Only PDF files are allowed.');
      setFile(null);
      return;
    }

    const maxSizeInBytes = 50 * 1024 * 1024; // 50MB
    if (selectedFile.size > maxSizeInBytes) {
      setUploadError('File size must be less than 50MB.');
      setFile(null);
      return;
    }

    setFile(selectedFile);
  };


  const handleUpload = () => {
    if (!file) {
      setUploadError('Please select a file to upload.');
      return;
    }

    setShowUploadedPopup(true);
    setTimeout(() => {
      setShowUploadedPopup(false);
      setIsModalOpen(false);
    }, 3000); // Hide after 3 seconds

  };

  const handleCloseModal = () => setIsModalOpen(false);

  const handleCloseApprovalComment = () => {
    setShowApprovalComment(false);
    setSelectedApprovalRole(null);
  };

  const handleDecisionChange = (e) => {
    setDecision(e.target.value);
  };

  const handlePriorityChange = (e) => {
    setPriority(e.target.value);
  };

  const handleCommentsChange = (e) => {
    setCommentsText(e.target.value);
  };
  const handleSend = () => {
    setShowSentPopup(true);
    setTimeout(() => {
      setShowSentPopup(false);
    }, 3000); // Hide after 3 seconds

    // Here you would typically send the data to your backend
    console.log("Decision:", decision);
    console.log("Priority:", priority);
    console.log("Comments:", commentsText);
  };

  const handleDownload = () => {
    // Replace 'your_file_url' with the actual URL of the PDF file
    const fileUrl = 'your_file_url'; // e.g., '/files/Organizational_Cyber_Management_Policy.pdf'

    // Create a temporary link element
    const link = document.createElement('a');
    link.href = fileUrl;

    // Set the download attribute and the filename
    link.download = 'Organizational Cyber Management Policy.pdf'; // Set the desired filename

    // Append the link to the document
    document.body.appendChild(link);

    // Trigger the download
    link.click();

    // Remove the link from the document
    document.body.removeChild(link);
  };


  return (
    <div className="container mx-auto p-4 bg-gray-50 text-sm">
      {/* Reduced padding, lighter background, base font size */}
      <h1 className="text-2xl font-semibold mb-4 text-gray-800">Request Overview</h1>

      {showSentPopup && (
        <div className="fixed top-4 left-1/2 transform -translate-x-1/2 bg-green-400 text-white py-2 px-4 rounded-md shadow-md z-50">
          {/* Softer green */}
          Sent it!
        </div>
      )}

      {showUploadedPopup && (
        <div className="fixed top-4 left-1/2 transform -translate-x-1/2 bg-green-400 text-white py-2 px-4 rounded-md shadow-md z-50">
          {/* Softer green */}
          Uploaded!
        </div>
      )}

      <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-4">
        {/* Reduced gap and margin */}
        {/* Company Information Section */}
        <div className="bg-white p-4 rounded-lg shadow-md hover:scale-105 transition duration-200">
          {/* Reduced padding, added transition */}
          <h2 className="text-xl font-semibold mb-3 text-gray-700 flex items-center">Company Information</h2>
          {/* Smaller header, added icon */}
          <p className="text-gray-600 flex items-center mb-1"><FaIdCard className="mr-2 text-yellow-500" /> <strong>Company Name:</strong> BAYDO Corporation</p>
          {/* Reduced text color, added icon */}
          <p className="text-gray-600 flex items-center mb-1"><FaMapMarkerAlt className="mr-2 text-red-500" /> <strong>Company Address:</strong> 123 Meskel Adebaby, Addis Ababa</p>
          <p className="text-gray-600 flex items-center mb-1"><FaPhone className="mr-2 text-green-500" /> <strong>Company Phone:</strong> <span className="text-gray-700">+251-965-686-679</span></p>
          <p className="text-gray-600 flex items-center mb-1">
            <FaEnvelope className="mr-2 text-purple-500" />
            <strong>Company Email:</strong>
            <a href="mailto:barawsfa20@gmail.com" className="text-blue-400 hover:underline"> barawsfa20@gmail.com</a>
            {/* Softer blue */}
          </p>
        </div>

        {/* Request Details Section */}
        <div className="bg-white p-4 rounded-lg shadow-md hover:scale-105 transition duration-200">
          {/* Reduced padding, added transition */}
          <h2 className="text-xl font-semibold mb-3 text-gray-700 flex items-center"> Request Details</h2>
          {/* Smaller header, added icon */}
          <p className="text-gray-600 flex items-center mb-1"><FaIdCard className="mr-2 text-yellow-500" /> <strong>Company Name:</strong> BAYDO Corporation</p>
          {/* Reduced text color, added icon */}
          <p className="text-gray-600 flex items-center mb-1"><FaMapMarkerAlt className="mr-2 text-red-500" /> <strong>Company Address:</strong> 123 Meskel Adebaby, Addis Ababa</p>
          <p className="text-gray-600 flex items-center mb-1"><FaPhone className="mr-2 text-green-500" /> <strong>Company Phone:</strong> <span className="text-gray-700">+251-965-686-679</span></p>
          <p className="text-gray-600 flex items-center mb-1">
            <FaEnvelope className="mr-2 text-purple-500" />
            <strong>Company Email:</strong>
            <a href="mailto:barawsfa20@gmail.com" className="text-blue-400 hover:underline"> barawsfa20@gmail.com</a>
            {/* Softer blue */}
          </p>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-4">
        <div className="bg-white p-4 rounded-lg shadow-md hover:scale-105 transition duration-200">
          <h2 className="text-xl font-semibold mb-3 text-gray-700">Request Service</h2>

          {/* Cyber Security Risk Management Service */}
          <div className="mb-6">
            <div className="flex items-center mb-2">
              <span className="text-green-400">
                <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 10V3l-8 8h5v8h6m1-5l5-5-5-5" />
                </svg>
              </span>
              <span className="font-medium text-gray-600 ml-2">Cyber Security Risk Management Service</span>
            </div>
            <ul className="list-disc pl-5">
              <li className="text-gray-600"><strong className="text-blue-500">Strategic Level Risk Assessment</strong> - 600,000-1,500.00</li>
              <li className="text-gray-600"><strong className="text-blue-500">Tactical Level Risk Assessment</strong> - 680,000-1,700.00</li>
              <li className="text-gray-600"><strong className="text-blue-500">Operational Level Risk Assessment</strong> - 680,000-1,700.00</li>
            </ul>
          </div>

          {/* Cyber Security Management Service */}
          <div>
            <div className="flex items-center mb-2">
              <span className="text-green-400">
                <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 10V3l-8 8h5v8h6m1-5l5-5-5-5" />
                </svg>
              </span>
              <span className="font-medium text-gray-600 ml-2">Cyber Security Management Service</span>
            </div>
            <ul className="list-disc pl-5">
              <li className="text-gray-600"><strong className="text-blue-500">Strategic Level Risk Assessment</strong> - 600,000-1,500.00</li>
            </ul>
          </div>
        </div>

        {/* Request Documents Section */}
        <div className="bg-white p-4 rounded-lg shadow-md hover:scale-105 transition duration-200">
          <h2 className="text-xl font-semibold mb-3 text-gray-700">Request Documents</h2>
          <div className="flex items-center justify-between h-20">
            <span className="text-gray-600">Organizational Cyber Management Policy.pdf</span>
            <div className="flex items-center">
              <FaDownload className="text-orange-400 cursor-pointer" onClick={handleDownload} />
            </div>
          </div>
        </div>
      </div>


      {/* Approval Status and Choose Your Final Task */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-4">
        {/* Approval Status Section */}
        <div className="bg-white p-4 rounded-lg shadow-md hover:scale-105 transition duration-200">
          <h2 className="text-xl font-semibold mb-3 text-gray-700">Approval Status</h2>
          <div className="space-y-3">
            {approvalStatus.map((status, idx) => (
              <div key={idx} className="flex items-center justify-between p-2 bg-purple-50 rounded-lg">
                <span className="text-gray-600">{status.role}</span>
                <button
                  className="p-1 hover:bg-gray-100 rounded-full"
                  onClick={() => handleView(status.role)}
                >
                  <FaFileAlt className="text-blue-400" />
                </button>
              </div>
            ))}
          </div>
        </div>

        {/* Choose Your Final Task Section */}
        <div className="bg-white p-4 rounded-lg shadow-md hover:scale-105 transition duration-200 flex flex-col items-center justify-center">
          <h2 className="text-xl font-semibold mb-3 text-gray-700">Choose Your Final Task</h2>
          <button className="bg-purple-500 text-white py-2 px-4 rounded-md hover:bg-purple-600 transition duration-200" onClick={handleUploadClick}>
            Upload the Report
          </button>
        </div>
      </div>

      {isModalOpen && (
        <div className="fixed inset-0 flex items-center justify-center bg-black bg-opacity-50">
          <div className="bg-white p-4 rounded-lg shadow-lg w-11/12 md:w-[600px] h-[300px] flex flex-col items-center justify-between">
            {/* Increased height for title */}
            <h2 className="text-xl font-semibold mb-3 text-gray-700">Upload Report</h2>
            <p className="text-gray-600 mb-4">Choose your report to upload:</p>
            {/* Added title */}
            <div
              className={`border-4 border-dashed border-gray-300 rounded-lg h-20 w-full flex items-center justify-center text-gray-500 text-sm cursor-pointer hover:border-blue-400 transition duration-200 ${uploadError ? 'border-red-500' : ''}`}
              onDrop={handleDrop}
              onDragOver={(e) => e.preventDefault()}
              onClick={() => document.getElementById('file-input').click()}
            >
              {/* Softer colors */}
              <input type="file" id="file-input" onChange={handleFileChange} className="hidden" accept="application/pdf" />
              {file ? <span className="text-gray-600">{file.name}</span> : <span>Drag & Drop or Click to Upload</span>}
            </div>
            {uploadError && <p className="text-red-500 mt-1">{uploadError}</p>}
            {/* Display error message */}
            <div className="flex justify-end mt-3">
              {/* Reduced margin */}
              <button className="bg-blue-400 text-white py-2 px-3 rounded-md hover:bg-blue-500 transition duration-200" onClick={handleUpload} disabled={!file}>Upload</button>
              {/* Softer blue */}
              <button className="bg-gray-200 text-gray-600 py-2 px-3 rounded-md hover:bg-gray-300 transition duration-200 ml-2" onClick={handleCloseModal}>Cancel</button>
              {/* Softer gray */}
            </div>
          </div>
        </div>
      )}

      {showApprovalComment && (
        <div className="fixed inset-0 flex items-center justify-center bg-black bg-opacity-50">
          <div className="bg-white p-4 rounded-lg shadow-lg w-11/12 md:w-[400px]">
            {/* Reduced padding and width */}
            <h2 className="text-xl font-semibold mb-3 text-gray-700">{selectedApprovalRole} Comment</h2>
            {/* Dynamic title */}
            <p className="text-gray-600">{approvalStatus.find(status => status.role === selectedApprovalRole)?.comment}</p>
            {/* Dynamic comment */}
            <div className="flex justify-end mt-3">
              {/* Reduced margin */}
              <button className="bg-gray-200 text-gray-600 py-2 px-3 rounded-md hover:bg-gray-300 transition duration-200" onClick={handleCloseApprovalComment}>Close</button>
              {/* Softer gray */}
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default RequestOverview;